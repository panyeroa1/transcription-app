// Speech-to-text provider factory
const config = require("../config")
const GeminiSTTProvider = require("./gemini")
const GoogleSTTProvider = require("./google")

// Factory function to create the appropriate STT provider
function createSTTProvider() {
  const provider = config.speechToText.provider.toLowerCase()

  switch (provider) {
    case "gemini":
      return new GeminiSTTProvider()
    case "google":
      return new GoogleSTTProvider()
    default:
      console.warn(`Unknown STT provider: ${provider}, falling back to Google`)
      return new GoogleSTTProvider()
  }
}

module.exports = { createSTTProvider }
