// Gemini API integration for speech-to-text
const config = require("../config")
const fetch = require("node-fetch")

class GeminiSTTProvider {
  constructor() {
    this.apiKey = config.speechToText.geminiApiKey
    if (!this.apiKey) {
      throw new Error("Gemini API key is not configured")
    }
    this.baseUrl = "https://generativelanguage.googleapis.com/v1beta"
  }

  async transcribe(audioBuffer) {
    try {
      // Convert audio buffer to base64
      const audioContent = audioBuffer.toString("base64")

      // Prepare request to Gemini API
      const response = await fetch(`${this.baseUrl}/models/gemini-pro-vision:generateContent?key=${this.apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: "Please transcribe this audio with speaker diarization. Format as: [Speaker 1]: text [Speaker 2]: text",
                },
                {
                  inline_data: {
                    mime_type: "audio/webm",
                    data: audioContent,
                  },
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.2,
            maxOutputTokens: 1024,
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`Gemini API error: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      // Process the response to extract transcript with speakers
      // This is a simplified example - actual implementation would need to parse the response format
      const transcriptText = data.candidates[0].content.parts[0].text

      // Parse the transcript to extract speakers and text
      return this.parseTranscript(transcriptText)
    } catch (error) {
      console.error("Gemini transcription error:", error)
      throw error
    }
  }

  parseTranscript(text) {
    // Parse the transcript to extract speakers and segments
    // This is a simplified implementation
    const speakerPattern = /\[Speaker (\d+)\]: (.*?)(?=\[Speaker \d+\]|$)/gs
    const segments = []
    let match

    while ((match = speakerPattern.exec(text)) !== null) {
      const speaker = Number.parseInt(match[1], 10)
      const content = match[2].trim()

      if (content) {
        segments.push({
          speaker,
          text: content,
          confidence: 0.9, // Gemini doesn't provide confidence scores
          startTime: null, // Gemini doesn't provide timestamps
          endTime: null,
        })
      }
    }

    return segments
  }
}

module.exports = GeminiSTTProvider
