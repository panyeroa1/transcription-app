// Configuration management for API keys and sensitive data
require("dotenv").config()

// Export configuration with safe defaults
module.exports = {
  // Server configuration
  port: process.env.PORT || 3000,

  // Database configuration
  database: {
    url: process.env.DATABASE_URL,
    host: process.env.DB_HOST || "localhost",
    port: process.env.DB_PORT || 5432,
    name: process.env.DB_NAME || "finla_transcription",
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
  },

  // Speech-to-Text configuration
  speechToText: {
    provider: process.env.STT_PROVIDER || "google", // 'google', 'gemini', etc.
    googleCredentialsPath: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    geminiApiKey: process.env.GEMINI_API_KEY,
    openaiApiKey: process.env.OPENAI_API_KEY,
  },

  // Environment detection
  isProduction: process.env.NODE_ENV === "production",
  isDevelopment: process.env.NODE_ENV !== "production",
}
