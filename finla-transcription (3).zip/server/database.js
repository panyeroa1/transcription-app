const { Pool } = require("pg")
require("dotenv").config()

// Create PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
})

// Database helper functions
class Database {
  // Initialize a new session
  static async createSession(sessionId) {
    const query = `
      INSERT INTO transcription_sessions (id, start_time, status)
      VALUES ($1, CURRENT_TIMESTAMP, 'active')
      ON CONFLICT (id) DO NOTHING
      RETURNING *
    `
    const result = await pool.query(query, [sessionId])
    return result.rows[0]
  }

  // Store audio chunk
  static async storeAudioChunk(sessionId, chunkIndex, audioBuffer, contentType = "audio/webm") {
    const query = `
      INSERT INTO audio_chunks (session_id, chunk_index, audio_data, content_type, file_size)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (session_id, chunk_index) 
      DO UPDATE SET 
        audio_data = EXCLUDED.audio_data,
        file_size = EXCLUDED.file_size,
        created_at = CURRENT_TIMESTAMP
      RETURNING id
    `
    const result = await pool.query(query, [sessionId, chunkIndex, audioBuffer, contentType, audioBuffer.length])
    return result.rows[0]
  }

  // Store transcript entries
  static async storeTranscriptEntries(sessionId, chunkIndex, entries) {
    if (!entries || entries.length === 0) return []

    const values = entries.map((entry, index) => [
      sessionId,
      chunkIndex,
      entry.speaker || 1,
      entry.text,
      entry.startTime ? Math.floor(entry.startTime.seconds * 1000 + entry.startTime.nanos / 1000000) : null,
      entry.endTime ? Math.floor(entry.endTime.seconds * 1000 + entry.endTime.nanos / 1000000) : null,
      entry.confidence || null,
      JSON.stringify(entry.words || []),
    ])

    const placeholders = values
      .map((_, i) => {
        const base = i * 8
        return `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6}, $${base + 7}, $${base + 8})`
      })
      .join(", ")

    const query = `
      INSERT INTO transcript_entries 
      (session_id, chunk_index, speaker, text, start_time_ms, end_time_ms, confidence, word_data)
      VALUES ${placeholders}
      RETURNING *
    `

    const flatValues = values.flat()
    const result = await pool.query(query, flatValues)
    return result.rows
  }

  // Get session transcript
  static async getSessionTranscript(sessionId) {
    const query = `
      SELECT * FROM transcript_entries 
      WHERE session_id = $1 
      ORDER BY chunk_index, start_time_ms, id
    `
    const result = await pool.query(query, [sessionId])
    return result.rows
  }

  // Get session info
  static async getSession(sessionId) {
    const query = `
      SELECT s.*, 
             COUNT(t.id) as transcript_count,
             COUNT(a.id) as audio_chunk_count
      FROM transcription_sessions s
      LEFT JOIN transcript_entries t ON s.id = t.session_id
      LEFT JOIN audio_chunks a ON s.id = a.session_id
      WHERE s.id = $1
      GROUP BY s.id
    `
    const result = await pool.query(query, [sessionId])
    return result.rows[0]
  }

  // Get combined audio data for export
  static async getCombinedAudio(sessionId) {
    const query = `
      SELECT audio_data, chunk_index, content_type
      FROM audio_chunks 
      WHERE session_id = $1 
      ORDER BY chunk_index
    `
    const result = await pool.query(query, [sessionId])
    return result.rows
  }

  // Update session status
  static async updateSessionStatus(sessionId, status, metadata = {}) {
    const query = `
      UPDATE transcription_sessions 
      SET status = $2, metadata = metadata || $3::jsonb, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `
    const result = await pool.query(query, [sessionId, status, JSON.stringify(metadata)])
    return result.rows[0]
  }

  // Clean up old sessions (optional maintenance)
  static async cleanupOldSessions(daysOld = 30) {
    const query = `
      DELETE FROM transcription_sessions 
      WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '${daysOld} days'
      AND status IN ('completed', 'failed')
    `
    const result = await pool.query(query)
    return result.rowCount
  }

  // Get database health info
  static async getHealthInfo() {
    const queries = [
      "SELECT COUNT(*) as total_sessions FROM transcription_sessions",
      "SELECT COUNT(*) as active_sessions FROM transcription_sessions WHERE status = 'active'",
      "SELECT COUNT(*) as total_chunks FROM audio_chunks",
      "SELECT COUNT(*) as total_transcripts FROM transcript_entries",
      "SELECT pg_size_pretty(pg_database_size(current_database())) as db_size",
    ]

    const results = {}
    for (const query of queries) {
      const result = await pool.query(query)
      Object.assign(results, result.rows[0])
    }

    return results
  }
}

// Handle pool errors
pool.on("error", (err) => {
  console.error("Unexpected error on idle client", err)
  process.exit(-1)
})

// Graceful shutdown
process.on("SIGINT", () => {
  console.log("Closing database pool...")
  pool.end(() => {
    console.log("Database pool closed.")
    process.exit(0)
  })
})

module.exports = { pool, Database }
