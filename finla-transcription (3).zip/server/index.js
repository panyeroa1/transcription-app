const express = require("express")
const multer = require("multer")
const path = require("path")
const speech = require("@google-cloud/speech")
const { Database } = require("./database")
require("dotenv").config()

const app = express()
const port = process.env.PORT || 3000

// Configure Google Speech-to-Text
const speechClient = new speech.SpeechClient({
  keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
})

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
})

// Store active SSE connections
const sseConnections = new Map()

// Middleware
app.use(express.json())
app.use(express.static("public"))

// CORS middleware
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization")
  if (req.method === "OPTIONS") {
    res.sendStatus(200)
  } else {
    next()
  }
})

// Speech-to-Text endpoint
app.post("/api/stt", upload.single("audio"), async (req, res) => {
  try {
    const { sessionId, chunkIndex } = req.body
    const audioBuffer = req.file.buffer

    console.log(`Processing chunk ${chunkIndex} for session ${sessionId}`)

    // Create session if it doesn't exist
    await Database.createSession(sessionId)

    // Store audio chunk in PostgreSQL
    await Database.storeAudioChunk(sessionId, Number.parseInt(chunkIndex), audioBuffer)

    // Process with Google Speech-to-Text
    const request = {
      audio: {
        content: audioBuffer.toString("base64"),
      },
      config: {
        encoding: "WEBM_OPUS",
        sampleRateHertz: 48000,
        languageCode: "en-US",
        model: "medical_conversation",
        enableSpeakerDiarization: true,
        diarizationConfig: {
          enableSpeakerDiarization: true,
          minSpeakerCount: 1,
          maxSpeakerCount: 10,
        },
        enableAutomaticPunctuation: true,
        enableWordTimeOffsets: true,
      },
    }

    const [response] = await speechClient.recognize(request)
    const transcription = response.results
      .map((result) => result.alternatives[0])
      .filter((alternative) => alternative.transcript.trim().length > 0)

    // Process transcription results
    const transcriptEntries = []
    for (const alternative of transcription) {
      const words = alternative.words || []
      let currentSpeaker = null
      let currentText = ""
      let startTime = null
      let endTime = null

      for (const word of words) {
        const speakerTag = word.speakerTag || 1

        if (currentSpeaker !== speakerTag) {
          // Save previous speaker's text
          if (currentText.trim()) {
            transcriptEntries.push({
              speaker: currentSpeaker,
              text: currentText.trim(),
              startTime: startTime,
              endTime: endTime,
              confidence: alternative.confidence,
              words: words.filter((w) => w.speakerTag === currentSpeaker),
            })
          }

          // Start new speaker
          currentSpeaker = speakerTag
          currentText = word.word
          startTime = word.startTime
        } else {
          currentText += " " + word.word
        }
        endTime = word.endTime
      }

      // Add final entry
      if (currentText.trim()) {
        transcriptEntries.push({
          speaker: currentSpeaker,
          text: currentText.trim(),
          startTime: startTime,
          endTime: endTime,
          confidence: alternative.confidence,
          words: words.filter((w) => w.speakerTag === currentSpeaker),
        })
      }
    }

    // Store transcript entries in database
    const storedEntries = await Database.storeTranscriptEntries(
      sessionId,
      Number.parseInt(chunkIndex),
      transcriptEntries,
    )

    // Send updates via Server-Sent Events
    const sseConnection = sseConnections.get(sessionId)
    if (sseConnection) {
      for (const entry of storedEntries) {
        sseConnection.write(
          `data: ${JSON.stringify({
            type: "transcript",
            speaker: entry.speaker,
            text: entry.text,
            timestamp: entry.timestamp_created,
            chunkIndex: entry.chunk_index,
            confidence: entry.confidence,
          })}\n\n`,
        )
      }
    }

    res.json({ success: true, entriesProcessed: storedEntries.length })
  } catch (error) {
    console.error("STT processing error:", error)
    res.status(500).json({ error: "Failed to process audio" })
  }
})

// Server-Sent Events endpoint for live updates
app.get("/api/live/:sessionId", (req, res) => {
  const { sessionId } = req.params

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "Access-Control-Allow-Origin": "*",
  })

  // Store connection
  sseConnections.set(sessionId, res)

  // Send initial connection confirmation
  res.write(
    `data: ${JSON.stringify({
      type: "status",
      message: "Connected to live stream",
    })}\n\n`,
  )

  // Handle client disconnect
  req.on("close", () => {
    sseConnections.delete(sessionId)
  })

  // Keep connection alive
  const keepAlive = setInterval(() => {
    res.write(
      `data: ${JSON.stringify({
        type: "ping",
        timestamp: new Date().toISOString(),
      })}\n\n`,
    )
  }, 30000)

  req.on("close", () => {
    clearInterval(keepAlive)
  })
})

// Export endpoint
app.get("/api/export/:sessionId", async (req, res) => {
  try {
    const { sessionId } = req.params
    const { format } = req.query

    switch (format) {
      case "webm":
        // Get combined audio data
        const audioChunks = await Database.getCombinedAudio(sessionId)
        if (audioChunks.length === 0) {
          return res.status(404).json({ error: "No audio data found" })
        }

        // Combine all audio chunks
        const totalSize = audioChunks.reduce((sum, chunk) => sum + chunk.audio_data.length, 0)
        const combinedBuffer = Buffer.alloc(totalSize)
        let offset = 0

        for (const chunk of audioChunks) {
          chunk.audio_data.copy(combinedBuffer, offset)
          offset += chunk.audio_data.length
        }

        res.setHeader("Content-Type", "audio/webm")
        res.setHeader("Content-Disposition", `attachment; filename="${sessionId}.webm"`)
        res.send(combinedBuffer)
        break

      case "json":
        // Get session data with transcript
        const session = await Database.getSession(sessionId)
        const transcript = await Database.getSessionTranscript(sessionId)

        const exportData = {
          session: session,
          transcript: transcript,
          exportedAt: new Date().toISOString(),
        }

        res.setHeader("Content-Type", "application/json")
        res.setHeader("Content-Disposition", `attachment; filename="${sessionId}.json"`)
        res.json(exportData)
        break

      case "txt":
        // Generate clean text file
        const transcriptEntries = await Database.getSessionTranscript(sessionId)
        const cleanText = transcriptEntries
          .map((entry) => {
            const timestamp = new Date(entry.timestamp_created).toLocaleTimeString()
            return `[${timestamp}] Speaker ${entry.speaker}: ${entry.text}`
          })
          .join("\n")

        res.setHeader("Content-Type", "text/plain")
        res.setHeader("Content-Disposition", `attachment; filename="${sessionId}.txt"`)
        res.send(cleanText)
        break

      default:
        return res.status(400).json({ error: "Invalid format" })
    }
  } catch (error) {
    console.error("Export error:", error)
    res.status(500).json({ error: "Failed to generate export" })
  }
})

// Session info endpoint
app.get("/api/session/:sessionId", async (req, res) => {
  try {
    const { sessionId } = req.params
    const session = await Database.getSession(sessionId)

    if (!session) {
      return res.status(404).json({ error: "Session not found" })
    }

    res.json(session)
  } catch (error) {
    console.error("Session info error:", error)
    res.status(500).json({ error: "Failed to get session info" })
  }
})

// Health check endpoint
app.get("/api/health", async (req, res) => {
  try {
    const dbHealth = await Database.getHealthInfo()

    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      activeConnections: sseConnections.size,
      database: dbHealth,
    })
  } catch (error) {
    console.error("Health check error:", error)
    res.status(500).json({
      status: "unhealthy",
      error: error.message,
    })
  }
})

// Serve the main page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"))
})

// Start server
app.listen(port, () => {
  console.log(`🎙️ Finla Transcription Server running on port ${port}`)
  console.log(`📊 Health check: http://localhost:${port}/api/health`)
  console.log(`🗄️ Using PostgreSQL database`)
})

// Graceful shutdown
process.on("SIGTERM", () => {
  console.log("Shutting down gracefully...")

  // Close all SSE connections
  for (const [sessionId, connection] of sseConnections) {
    connection.end()
  }

  process.exit(0)
})
