class TranscriptionRecorder {
  constructor() {
    this.mediaRecorder = null
    this.audioChunks = []
    this.isRecording = false
    this.isPaused = false
    this.sessionId = this.generateSessionId()
    this.chunkIndex = 0
    this.startTime = null
    this.pausedTime = 0
    this.eventSource = null
    this.transcriptEntries = []
    this.maxTranscriptEntries = 5000

    this.initializeElements()
    this.setupEventListeners()
    this.updateSessionDisplay()
    this.connectToLiveStream()
  }

  generateSessionId() {
    return "session_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9)
  }

  initializeElements() {
    this.elements = {
      startBtn: document.getElementById("start-btn"),
      stopBtn: document.getElementById("stop-btn"),
      pauseBtn: document.getElementById("pause-btn"),
      resumeBtn: document.getElementById("resume-btn"),
      audioPlayer: document.getElementById("audio-player"),
      transcriptPanel: document.getElementById("transcript-panel"),
      copyBtn: document.getElementById("copy-btn"),
      downloadTxtBtn: document.getElementById("download-txt-btn"),
      downloadJsonBtn: document.getElementById("download-json-btn"),
      downloadAudioBtn: document.getElementById("download-audio-btn"),
      sessionId: document.getElementById("session-id"),
      recordingTime: document.getElementById("recording-time"),
      status: document.getElementById("status"),
      connectionStatus: document.getElementById("connection-status"),
    }
  }

  setupEventListeners() {
    this.elements.startBtn.addEventListener("click", () => this.startRecording())
    this.elements.stopBtn.addEventListener("click", () => this.stopRecording())
    this.elements.pauseBtn.addEventListener("click", () => this.pauseRecording())
    this.elements.resumeBtn.addEventListener("click", () => this.resumeRecording())
    this.elements.copyBtn.addEventListener("click", () => this.copyTranscript())
    this.elements.downloadTxtBtn.addEventListener("click", () => this.downloadTranscript("txt"))
    this.elements.downloadJsonBtn.addEventListener("click", () => this.downloadTranscript("json"))
    this.elements.downloadAudioBtn.addEventListener("click", () => this.downloadTranscript("webm"))
  }

  updateSessionDisplay() {
    this.elements.sessionId.textContent = `Session: ${this.sessionId}`
  }

  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100,
        },
      })

      this.mediaRecorder = new MediaRecorder(stream, {
        mimeType: "audio/webm;codecs=opus",
      })

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.handleAudioChunk(event.data)
        }
      }

      this.mediaRecorder.onstop = () => {
        this.finalizeRecording()
      }

      // Record in 10-second chunks
      this.mediaRecorder.start(10000)

      this.isRecording = true
      this.startTime = Date.now()
      this.updateUI()
      this.startTimer()
      this.updateStatus("Recording...")
    } catch (error) {
      console.error("Error starting recording:", error)
      this.updateStatus("Error: Could not access microphone")
    }
  }

  async handleAudioChunk(blob) {
    this.audioChunks.push(blob)

    // Send chunk to server for transcription
    const formData = new FormData()
    formData.append("audio", blob)
    formData.append("sessionId", this.sessionId)
    formData.append("chunkIndex", this.chunkIndex++)

    try {
      const response = await fetch("/api/stt", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      // The actual transcription will come via Server-Sent Events
    } catch (error) {
      console.error("Error sending audio chunk:", error)
      this.updateStatus("Error: Failed to send audio chunk")
    }
  }

  stopRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop()
      this.mediaRecorder.stream.getTracks().forEach((track) => track.stop())
    }
  }

  pauseRecording() {
    if (this.mediaRecorder && this.isRecording && !this.isPaused) {
      this.mediaRecorder.pause()
      this.isPaused = true
      this.pausedTime = Date.now()
      this.updateUI()
      this.updateStatus("Paused")
    }
  }

  resumeRecording() {
    if (this.mediaRecorder && this.isRecording && this.isPaused) {
      this.mediaRecorder.resume()
      this.isPaused = false
      this.startTime += Date.now() - this.pausedTime
      this.updateUI()
      this.updateStatus("Recording...")
    }
  }

  finalizeRecording() {
    this.isRecording = false
    this.isPaused = false

    // Create final audio blob
    const finalBlob = new Blob(this.audioChunks, { type: "audio/webm" })
    const audioUrl = URL.createObjectURL(finalBlob)

    this.elements.audioPlayer.src = audioUrl
    this.elements.audioPlayer.style.display = "block"

    this.updateUI()
    this.updateStatus("Recording completed")
    this.stopTimer()
  }

  updateUI() {
    this.elements.startBtn.disabled = this.isRecording
    this.elements.stopBtn.disabled = !this.isRecording
    this.elements.pauseBtn.disabled = !this.isRecording || this.isPaused
    this.elements.resumeBtn.disabled = !this.isPaused

    this.elements.pauseBtn.style.display = this.isPaused ? "none" : "flex"
    this.elements.resumeBtn.style.display = this.isPaused ? "flex" : "none"
  }

  startTimer() {
    this.timerInterval = setInterval(() => {
      if (!this.isPaused && this.startTime) {
        const elapsed = Date.now() - this.startTime
        this.elements.recordingTime.textContent = this.formatTime(elapsed)
      }
    }, 1000)
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval)
    }
  }

  formatTime(ms) {
    const seconds = Math.floor(ms / 1000)
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  connectToLiveStream() {
    if (this.eventSource) {
      this.eventSource.close()
    }

    this.eventSource = new EventSource(`/api/live/${this.sessionId}`)

    this.eventSource.onopen = () => {
      this.elements.connectionStatus.textContent = "🟢 Connected"
      this.elements.connectionStatus.className = "connected"
    }

    this.eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data)
      this.handleTranscriptUpdate(data)
    }

    this.eventSource.onerror = () => {
      this.elements.connectionStatus.textContent = "🔴 Disconnected"
      this.elements.connectionStatus.className = "disconnected"

      // Attempt to reconnect after 5 seconds
      setTimeout(() => {
        this.connectToLiveStream()
      }, 5000)
    }
  }

  handleTranscriptUpdate(data) {
    if (data.type === "transcript") {
      this.addTranscriptEntry(data)
    } else if (data.type === "status") {
      this.updateStatus(data.message)
    }
  }

  addTranscriptEntry(entry) {
    // Remove placeholder if it exists
    const placeholder = this.elements.transcriptPanel.querySelector(".transcript-placeholder")
    if (placeholder) {
      placeholder.remove()
    }

    // Create transcript entry element
    const entryElement = document.createElement("div")
    entryElement.className = "transcript-entry new"

    const timestamp = new Date(entry.timestamp).toLocaleTimeString()

    entryElement.innerHTML = `
            <div class="transcript-meta">
                <span class="speaker">Speaker ${entry.speaker || "Unknown"}</span>
                <span class="timestamp">${timestamp}</span>
            </div>
            <div class="transcript-text">${entry.text}</div>
        `

    this.elements.transcriptPanel.appendChild(entryElement)

    // Store entry
    this.transcriptEntries.push(entry)

    // Manage memory by removing old entries
    if (this.transcriptEntries.length > this.maxTranscriptEntries) {
      const entriesToRemove = this.transcriptEntries.length - this.maxTranscriptEntries
      this.transcriptEntries.splice(0, entriesToRemove)

      // Remove old DOM elements
      const oldEntries = this.elements.transcriptPanel.querySelectorAll(".transcript-entry")
      for (let i = 0; i < entriesToRemove && i < oldEntries.length; i++) {
        oldEntries[i].remove()
      }
    }

    // Auto-scroll to bottom
    this.elements.transcriptPanel.scrollTop = this.elements.transcriptPanel.scrollHeight

    // Remove 'new' class after animation
    setTimeout(() => {
      entryElement.classList.remove("new")
    }, 300)
  }

  copyTranscript() {
    const text = this.transcriptEntries
      .map(
        (entry) =>
          `[${new Date(entry.timestamp).toLocaleTimeString()}] Speaker ${entry.speaker || "Unknown"}: ${entry.text}`,
      )
      .join("\n")

    navigator.clipboard
      .writeText(text)
      .then(() => {
        this.updateStatus("Transcript copied to clipboard")
      })
      .catch(() => {
        this.updateStatus("Failed to copy transcript")
      })
  }

  async downloadTranscript(format) {
    try {
      const response = await fetch(`/api/export/${this.sessionId}?format=${format}`)

      if (response.ok) {
        // Server will redirect to S3 signed URL
        window.open(response.url, "_blank")
      } else {
        throw new Error("Export failed")
      }
    } catch (error) {
      console.error("Download error:", error)
      this.updateStatus(`Failed to download ${format.toUpperCase()}`)
    }
  }

  updateStatus(message) {
    this.elements.status.textContent = message

    // Clear status after 5 seconds
    setTimeout(() => {
      if (this.elements.status.textContent === message) {
        this.elements.status.textContent = "Ready"
      }
    }, 5000)
  }
}

// Initialize the recorder when the page loads
document.addEventListener("DOMContentLoaded", () => {
  new TranscriptionRecorder()
})
