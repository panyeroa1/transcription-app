# 🎙️ Finla Transcription

Real-time audio transcription with speaker diarization, PostgreSQL storage, and live streaming capabilities.

## ✨ Features

- **Real-time transcription** with 10-second chunking
- **Speaker diarization** using Google Speech-to-Text
- **Live streaming** via Server-Sent Events
- **PostgreSQL storage** for audio and transcripts
- **Multiple export formats** (WebM, JSON, TXT)
- **Responsive dark UI** optimized for mobile and desktop
- **Memory management** for long recordings (1+ hours)
- **PWA support** for mobile installation

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- PostgreSQL 12+
- Google Cloud Speech-to-Text API credentials

### Installation

1. **Clone and install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

2. **Set up PostgreSQL database:**
   \`\`\`bash
   # First, create the user and database (run as postgres superuser)
   sudo -u postgres psql -f scripts/00-setup-user.sql
   
   # Then create tables (run as finla user)
   psql -U finla -d finla_transcription -f scripts/01-create-database.sql
   psql -U finla -d finla_transcription -f scripts/02-seed-data.sql
   \`\`\`

3. **Set up environment variables:**
   \`\`\`bash
   cp .env.example .env
   # The database credentials are already configured for user 'finla'
   # Just add your Google Cloud and other API credentials
   \`\`\`

4. **Configure Google Cloud:**
   - Create a service account in Google Cloud Console
   - Download the JSON key file
   - Set `GOOGLE_APPLICATION_CREDENTIALS` path in `.env`

### Development

\`\`\`bash
npm run dev
\`\`\`

Visit `http://localhost:3000` to start transcribing!

### Production Deployment

**Vercel (Recommended):**
\`\`\`bash
npm run deploy
\`\`\`

**Manual deployment:**
\`\`\`bash
npm start
\`\`\`

## 📱 PWA Installation

### Mobile (iOS/Android):
1. Open the app in your mobile browser
2. Tap "Add to Home Screen" or "Install App"
3. Launch from your home screen for full-screen experience

### Desktop:
1. Look for the install icon in your browser's address bar
2. Click to install as a desktop app

## 🏗️ Architecture

### Frontend (`/public`)
- **HTML5** with responsive design
- **Vanilla JavaScript** for optimal performance
- **MediaRecorder API** for audio capture
- **Server-Sent Events** for live updates

### Backend (`/server`)
- **Express.js** server
- **Google Speech-to-Text** with medical conversation model
- **PostgreSQL** for persistent storage
- **Multer** for file upload handling

### Database Structure
\`\`\`sql
transcription_sessions/
├── id (session identifier)
├── created_at, updated_at
├── status, total_chunks
└── metadata (JSONB)

audio_chunks/
├── session_id, chunk_index
├── audio_data (BYTEA)
├── content_type, file_size
└── created_at

transcript_entries/
├── session_id, chunk_index
├── speaker, text
├── start_time_ms, end_time_ms
├── confidence, word_data
└── timestamp_created
\`\`\`

## 🔧 API Endpoints

- `POST /api/stt` - Process audio chunks
- `GET /api/live/:sessionId` - Server-Sent Events stream
- `GET /api/export/:sessionId?format=txt|json|webm` - Download exports
- `GET /api/session/:sessionId` - Get session information
- `GET /api/health` - Health check with database stats

## ⚡ Performance Optimizations

- **10-second chunking** prevents memory bloat
- **DOM recycling** for transcript entries (5,000 max)
- **Efficient PostgreSQL storage** with proper indexing
- **Connection pooling** for database connections
- **Automatic reconnection** for SSE streams
- **Binary storage** for audio data (BYTEA)

## 🎯 Success Metrics

✅ **Live transcript** with timestamps and speaker labels  
✅ **1-hour recordings** without crashes or memory issues  
✅ **PostgreSQL storage** with organized schema  
✅ **Responsive UI** tested on mobile and desktop  
✅ **Export functionality** in multiple formats  
✅ **Real-time streaming** with <10s latency  

## 🔒 Security

- CORS properly configured
- File size limits enforced
- PostgreSQL parameterized queries (SQL injection protection)
- Environment variables for sensitive data

## 🐛 Troubleshooting

**Database connection issues:**
- Verify PostgreSQL is running
- Check connection string in .env
- Ensure database exists and tables are created

**Microphone not working:**
- Ensure HTTPS (required for MediaRecorder)
- Check browser permissions
- Try refreshing the page

**Transcription not appearing:**
- Verify Google Cloud credentials
- Check network connectivity
- Monitor browser console for errors

## 📊 Database Maintenance

**View session summaries:**
\`\`\`sql
SELECT * FROM session_summaries ORDER BY created_at DESC;
\`\`\`

**Clean up old sessions:**
\`\`\`sql
-- Delete sessions older than 30 days
DELETE FROM transcription_sessions 
WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '30 days'
AND status IN ('completed', 'failed');
\`\`\`

**Check database size:**
\`\`\`sql
SELECT pg_size_pretty(pg_database_size('finla_transcription'));
\`\`\`

## 📄 License

MIT License - feel free to use for personal and commercial projects.
