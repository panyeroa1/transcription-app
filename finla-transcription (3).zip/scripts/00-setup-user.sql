-- Create the finla user and database
-- Run this as a PostgreSQL superuser (e.g., postgres user)

-- Create user if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'finla') THEN
        CREATE USER finla WITH PASSWORD 'finla123';
    END IF;
END
$$;

-- Create database if it doesn't exist
SELECT 'CREATE DATABASE finla_transcription OWNER finla'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'finla_transcription')\gexec

-- Grant necessary privileges
GRANT ALL PRIVILEGES ON DATABASE finla_transcription TO finla;

-- Connect to the new database and grant schema privileges
\c finla_transcription

-- Grant privileges on the public schema
GRANT ALL ON SCHEMA public TO finla;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO finla;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO finla;

-- Set default privileges for future objects
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO finla;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO finla;

-- Verify the setup
\du finla
\l finla_transcription
