-- Optional: Database setup for session metadata (if using RDS instead of S3 JSON)
-- This is an alternative approach for storing session metadata

CREATE TABLE IF NOT EXISTS transcription_sessions (
    id VARCHAR(255) PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    total_chunks INTEGER DEFAULT 0,
    total_duration_ms INTEGER DEFAULT 0,
    metadata JSON
);

CREATE TABLE IF NOT EXISTS transcript_entries (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    chunk_index INTEGER NOT NULL,
    speaker INTEGER,
    text TEXT NOT NULL,
    start_time_ms INTEGER,
    end_time_ms INTEGER,
    confidence DECIMAL(3,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES transcription_sessions(id) ON DELETE CASCADE,
    INDEX idx_session_chunk (session_id, chunk_index),
    INDEX idx_session_time (session_id, start_time_ms)
);

CREATE TABLE IF NOT EXISTS audio_chunks (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    chunk_index INTEGER NOT NULL,
    s3_key VARCHAR(500) NOT NULL,
    file_size INTEGER,
    duration_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES transcription_sessions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_session_chunk (session_id, chunk_index)
);
