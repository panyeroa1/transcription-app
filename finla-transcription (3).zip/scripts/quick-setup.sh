#!/bin/bash

# Quick setup script for Finla Transcription
echo "🎙️ Setting up Finla Transcription..."

# Check if PostgreSQL is running
if ! pg_isready > /dev/null 2>&1; then
    echo "❌ PostgreSQL is not running. Please start PostgreSQL first."
    exit 1
fi

# Create user and database (requires superuser privileges)
echo "📊 Creating database user and database..."
sudo -u postgres psql -f scripts/00-setup-user.sql

if [ $? -eq 0 ]; then
    echo "✅ Database user 'finla' created successfully"
else
    echo "⚠️ User creation failed or user already exists"
fi

# Create tables
echo "🗄️ Creating database tables..."
psql -U finla -d finla_transcription -f scripts/01-create-database.sql

if [ $? -eq 0 ]; then
    echo "✅ Database tables created successfully"
else
    echo "❌ Failed to create tables"
    exit 1
fi

# Seed data
echo "🌱 Seeding initial data..."
psql -U finla -d finla_transcription -f scripts/02-seed-data.sql

# Copy environment file
if [ ! -f .env ]; then
    cp .env.example .env
    echo "📝 Created .env file from template"
    echo "⚠️ Please edit .env and add your API keys"
else
    echo "📝 .env file already exists"
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

echo ""
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file and add your Google Cloud credentials"
echo "2. Run 'npm run dev' to start the development server"
echo "3. Visit http://localhost:3000 to start transcribing"
echo ""
echo "Database connection: postgresql://finla:finla123@localhost:5432/finla_transcription"
