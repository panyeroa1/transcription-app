-- Database setup for Finla Transcription
-- Make sure to run scripts/00-setup-user.sql first as a superuser
-- Then run this script as the 'finla' user

-- Connect to the database
\c finla_transcription finla

-- Create the main database and tables for transcription storage

-- Create database (run this first as superuser)
-- CREATE DATABASE finla_transcription;

-- Connect to the database and create tables
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Sessions table to track recording sessions
CREATE TABLE IF NOT EXISTS transcription_sessions (
    id VARCHAR(255) PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    total_chunks INTEGER DEFAULT 0,
    total_duration_ms INTEGER DEFAULT 0,
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}'::jsonb
);

-- Audio chunks table to store binary audio data
CREATE TABLE IF NOT EXISTS audio_chunks (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    chunk_index INTEGER NOT NULL,
    audio_data BYTEA NOT NULL,
    content_type VARCHAR(100) DEFAULT 'audio/webm',
    file_size INTEGER NOT NULL,
    duration_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES transcription_sessions(id) ON DELETE CASCADE,
    UNIQUE (session_id, chunk_index)
);

-- Transcript entries table for processed speech-to-text results
CREATE TABLE IF NOT EXISTS transcript_entries (
    id BIGSERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    chunk_index INTEGER NOT NULL,
    speaker INTEGER,
    text TEXT NOT NULL,
    start_time_ms INTEGER,
    end_time_ms INTEGER,
    confidence DECIMAL(4,3),
    timestamp_created TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    word_data JSONB,
    FOREIGN KEY (session_id) REFERENCES transcription_sessions(id) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON transcription_sessions(created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_status ON transcription_sessions(status);

CREATE INDEX IF NOT EXISTS idx_audio_chunks_session ON audio_chunks(session_id);
CREATE INDEX IF NOT EXISTS idx_audio_chunks_session_index ON audio_chunks(session_id, chunk_index);

CREATE INDEX IF NOT EXISTS idx_transcript_session ON transcript_entries(session_id);
CREATE INDEX IF NOT EXISTS idx_transcript_session_chunk ON transcript_entries(session_id, chunk_index);
CREATE INDEX IF NOT EXISTS idx_transcript_session_time ON transcript_entries(session_id, start_time_ms);

-- Function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to automatically update updated_at
CREATE TRIGGER update_sessions_updated_at 
    BEFORE UPDATE ON transcription_sessions 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Grant permissions (adjust username as needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_username;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_username;
