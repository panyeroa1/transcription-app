-- Optional: Insert some sample data for testing

-- Insert a test session
INSERT INTO transcription_sessions (
    id, 
    status, 
    start_time,
    metadata
) VALUES (
    'test_session_' || extract(epoch from now())::text,
    'completed',
    CURRENT_TIMESTAMP - INTERVAL '1 hour',
    '{"test": true, "description": "Sample session for testing"}'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- You can add sample transcript entries here if needed for testing
-- INSERT INTO transcript_entries (session_id, chunk_index, speaker, text, start_time_ms)
-- VALUES ('test_session_123', 0, 1, 'Hello, this is a test transcription.', 0);

-- View to get session summaries
CREATE OR REPLACE VIEW session_summaries AS
SELECT 
    s.id,
    s.created_at,
    s.status,
    s.total_chunks,
    s.total_duration_ms,
    COUNT(t.id) as transcript_count,
    COUNT(DISTINCT t.speaker) as speaker_count,
    MIN(t.timestamp_created) as first_transcript,
    MAX(t.timestamp_created) as last_transcript
FROM transcription_sessions s
LEFT JOIN transcript_entries t ON s.id = t.session_id
GROUP BY s.id, s.created_at, s.status, s.total_chunks, s.total_duration_ms
ORDER BY s.created_at DESC;
